export interface Track {
	id: Number;
	title: string;
	creator: string;
	trackName: string;
}
