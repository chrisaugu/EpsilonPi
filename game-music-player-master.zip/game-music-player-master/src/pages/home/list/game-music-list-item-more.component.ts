import { Component } from '@angular/core';

@Component({
	selector: 'game-music-list-item-more',
	template: `
		<div class="game-music-list-item__container__more" clear>

		</div>
	`,
})
export class GameMusicListItemMore {

}
