export enum ListSource {
	ALL,
	FAVES,
}
