import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-hereos',
  templateUrl: './manage-heroes.component.html',
  styleUrls: ['./manage-heroes.component.css']
})
export class ManageHeroesComponent { }


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/